<?php
$conn = mysqli_connect("localhost", "root", "", "ikart");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
