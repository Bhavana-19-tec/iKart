<?php
session_start();

// Save product to "Buy Later"
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_for_later'])) {
    $item = [
        'name' => $_POST['product_name'],
        'price' => $_POST['product_price'],
        'image' => $_POST['product_image']
    ];

    if (!isset($_SESSION['buy_later'])) {
        $_SESSION['buy_later'] = [];
    }

    $_SESSION['buy_later'][] = $item;

    // Redirect back to products
    header("Location: buy_later.php");
    exit;
}

$buyLaterList = $_SESSION['buy_later'] ?? [];
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Buy Later - IKART</title>
  <link href="https://fonts.googleapis.com/css2?family=Inria+Serif&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="Ikart.css" />
  <style>
    html, body {
  font-family: 'Inria Serif', serif;
  background-color: #fcf6f6;
  color: #0a1a40; /* Changed from #e0e0e0 to readable dark color */
  overflow-x: hidden;
  min-height: 100vh;
  line-height: 1.5;
}

a {
  color: #ffcc00;
  text-decoration: none;
  transition: color 0.3s ease;
}

a:hover, a:focus {
  color: #e6b800;
  text-decoration: underline;
}

h1, h2, h3, h4, h5, h6 {
  color: #fff;
  margin-bottom: 1rem;
}

ul {
  list-style-type: none;
}

button {
  font-family: 'Inria Serif', serif;
}

/* === Navbar === */
.navbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: #081943; /* Updated Navy Blue */
  padding: 10px 20px;
  position: sticky;
  top: 0;
  z-index: 1000;
  box-shadow: 0 2px 8px rgba(10, 9, 9, 0.2); /* Optional: shadow for visibility */
}

.navbar .logo img {
  height: 50px;
}

.navbar nav ul {
  display: flex;
  gap: 20px;
  align-items: center;
}

.navbar nav ul li a,
.navbar nav ul li select {
  color: #e0e0e0;
  font-weight: 600;
  padding: 6px 10px;
  border-radius: 4px;
  font-size: 1rem;
  background: transparent;
  border: none;
  cursor: pointer;
}

.navbar nav ul li a.active,
.navbar nav ul li a:hover,
.navbar nav ul li select:hover,
.navbar nav ul li select:focus {
  background-color: hwb(60 97% 3%);
  color: #0a1a40;
  outline: none;
}

.dropdown-nav select {
  font-family: 'Inria Serif', serif;
}

/* === Footer === */
.site-footer, .footer {
  background-color: #07173d; /* Match navbar navy blue */
  color: #e0e0e0;
  text-align: center;
  padding: 20px 10px;
  font-size: 0.9rem;
  box-shadow: 0 -2px 8px rgba(7, 7, 7, 0.2); /* Optional: top shadow for separation */
}

.site-footer .footer-content,
.footer-content {
  max-width: 960px;
  margin: 0 auto;
}

.site-footer .social-icons a {
  margin: 0 8px;
  color: #ffcc00;
  font-size: 1.5rem;
}

.site-footer .social-icons a:hover,
.site-footer .social-icons a:focus {
  color: #e6b800;
}
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
    body {
      font-family: 'Inria Serif', serif;
      margin: 0;
      background-color: #f5f5f5;
    }
    header {
      background-color: #000305;
      color: white;
      padding: 20px;
      text-align: center;
    }
    .logo {
      padding: 10px;
      background-color: #fff;
    }
    .logo img {
      height: 50px;
    }
    .product-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
      gap: 20px;
      padding: 20px;
    }
    .product-card {
      background: white;
      border: 1px solid #ccc;
      border-radius: 10px;
      text-align: center;
      padding: 15px;
    }
    .product-card img {
      width: 150px;
      height: 150px;
      object-fit: cover;
    }
    .back-link {
      display: inline-block;
      margin-top: 10px;
      color: lightblue;
      text-decoration: none;
    }
  </style>
</head>
<body>

<!-- Logo -->
<div class="logo">
  <a href="index.php">
    <img src="IMAGES/IKART.png" alt="IKART Logo">
  </a>
</div>

<!-- Header -->
<header>
  <h1>🕒 Items Saved for Later</h1>
  <a href="product.php" class="back-link">← Back to Products</a>
</header>

<!-- Product Grid -->
<main>
  <div class="product-grid">
    <?php if (empty($buyLaterList)) : ?>
      <p style='grid-column: span 4; text-align:center;'>No items saved for later.</p>
    <?php else : ?>
      <?php foreach ($buyLaterList as $item) : ?>
        <div class="product-card">
          <img src="<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>">
          <h3><?php echo htmlspecialchars($item['name']); ?></h3>
          <p>Price: $<?php echo htmlspecialchars($item['price']); ?></p>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>
</main>

</body>
</html>
