<?php
session_start();
include "config.php"; // your DB connection

// Your secret key
$recaptchaSecret = "6LedkHQrAAAAALQ6-mRVfNvujfET_BSUtHsf9O4s";

// Check if reCAPTCHA response is set
if (!isset($_POST['g-recaptcha-response'])) {
    echo "<script>alert('Please complete the reCAPTCHA.'); window.location.href='login.html';</script>";
    exit();
}

$response = $_POST['g-recaptcha-response'];
// Verify the reCAPTCHA response with Google
$verify = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret={$recaptchaSecret}&response={$response}");
$responseData = json_decode($verify);

if (!$responseData->success) {
    echo "<script>alert('reCAPTCHA verification failed.'); window.location.href='login.html';</script>";
    exit();
}

// Sanitize email and password
$email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
$password = $_POST['password'];

// Fetch user from DB
$stmt = $conn->prepare("SELECT user_id, password FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if ($user && password_verify($password, $user['password'])) {
    $_SESSION['user_id'] = $user['user_id'];
    // Redirect to dashboard or home page after successful login
    header("Location: dashboard.php");
    exit();
} else {
    echo "<script>alert('Invalid credentials!'); window.location.href='login.html';</script>";
    exit();
}
?>
