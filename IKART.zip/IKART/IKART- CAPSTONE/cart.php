<?php
session_start();
include('db_connect.php');

// Initialize cart
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Handle Add to Cart and Remove logic (same as before)...

// Fetch products from DB
$product_ids = array_keys($_SESSION['cart']);
$products = [];
if (!empty($product_ids)) {
    $ids = implode(",", array_map('intval', $product_ids));
    $res = mysqli_query($conn, "SELECT * FROM products WHERE id IN ($ids)");
    while ($row = mysqli_fetch_assoc($res)) {
        $products[$row['id']] = $row;
    }
}

// Calculate totals
$subtotal = 0;
foreach ($_SESSION['cart'] as $id => $item) {
    if (isset($products[$id])) {
        $subtotal += $products[$id]['price'] * $item['quantity'];
    }
}
$tax = round($subtotal * 0.05, 2);
$total = $subtotal + $tax;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>iKart Cart</title>
</head>
<body style="font-family:'Inria Serif', serif; background:#fcf6f6; color:#0a1a40; margin:0; padding:20px;">

<!-- Navbar -->
<header style="display:flex; justify-content:space-between; align-items:center; background:#081943; padding:10px 20px; position:sticky; top:0;">
  <a href="Index.html"><img src="IMAGES/IKART.png" alt="IKART Logo" style="height:50px;"></a>
  <nav><ul style="list-style:none; display:flex; gap:20px; margin:0;">
    <li><a href="Index.html" style="color:#e0e0e0; font-weight:600; text-decoration:none;">Home</a></li>
    <li><a href="Product.html" style="color:#e0e0e0; font-weight:600; text-decoration:none;">Products</a></li>
    <li><a href="cart.php" style="color:#e0e0e0; font-weight:600; text-decoration:none;">🛒</a></li>
  </ul></nav>
</header>

<section style="margin:20px 0;">
  <h2>Your Cart</h2>
  <?php if (empty($_SESSION['cart'])): ?>
    <p>Your cart is empty. <a href="Product.html">Shop Now</a></p>
  <?php else: ?>
    <table style="width:100%; border-collapse:collapse; margin-bottom:20px;">
      <thead><tr style="background:#ddd;">
        <th style="padding:8px">Product</th>
        <th style="padding:8px">Qty</th>
        <th style="padding:8px">Price</th>
        <th style="padding:8px">Remove</th>
      </tr></thead>
      <tbody>
        <?php foreach ($_SESSION['cart'] as $id => $item):
          $p = $products[$id];
        ?>
        <tr>
          <td style="padding:8px">
            <a href="Product.php?id=<?= $id ?>" style="color:#007bff; text-decoration:none;">
              <?= htmlspecialchars($p['name']) ?>
            </a>
          </td>
          <td style="padding:8px; text-align:center;"><?= $item['quantity'] ?></td>
          <td style="padding:8px">$<?= number_format($p['price'] * $item['quantity'], 2) ?></td>
          <td style="padding:8px; text-align:center;">
            <form method="post" style="display:inline;">
              <input type="hidden" name="remove_id" value="<?= $id ?>">
              <button name="remove" style="background:none; border:none; cursor:pointer;">❌</button>
            </form>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

    <div style="margin-bottom:40px;">
      <p>Subtotal: $<?= number_format($subtotal,2) ?></p>
      <p>Tax (5%): $<?= number_format($tax,2) ?></p>
      <p><strong>Total: $<?= number_format($total,2) ?></strong></p>
    </div>
  <?php endif; ?>
</section>

<!-- Inline Product Row of Items in Cart -->
<?php if (!empty($products)): ?>
<section style="display:flex; gap:20px; flex-wrap:wrap; justify-content:center; margin:40px 0;">
  <?php foreach ($products as $p): $q = $_SESSION['cart'][$p['id']]['quantity']; ?>
    <div style="flex:1; min-width:200px; max-width:300px; background:#fff; border:1px solid #ddd; border-radius:4px; padding:15px; text-align:center;">
      <a href="Product.php?id=<?= $p['id'] ?>">
        <img src="<?= htmlspecialchars($p['image_url'] ?? 'placeholder.jpg') ?>"
             alt="<?= htmlspecialchars($p['name']) ?>"
             style="max-width:100%; height:auto; margin-bottom:10px;">
        <h3 style="margin:10px 0; color:#0a1a40;"><?= htmlspecialchars($p['name']) ?></h3>
      </a>
      <p>Qty: <?= $q ?></p>
      <p style="font-weight:bold; margin:10px 0;">$<?= number_format($p['price'] * $q,2) ?></p>
      <p>Expected Delivery: Jun 1 – Jun 5</p>
    </div>
  <?php endforeach; ?>
</section>
<?php endif; ?>
<main class="container">
  <h1>Shopping Cart</h1>

  <section id="cart-items" aria-label="Cart Items">
    <!-- Dynamically filled with JS -->
  </section>

  <section id="prescription-section" aria-label="Prescription Upload">
    <h2>Prescription Upload</h2>
    <input type="file" id="prescription-upload" accept="image/*,.pdf" />
    <p id="upload-status" role="alert" aria-live="polite"></p>
  </section>

  <section id="promo-section" aria-label="Promo Code">
    <h2>Promo Code</h2>
    <input type="text" id="promo-code" placeholder="Enter promo code" />
    <button id="apply-promo">Apply</button>
    <p id="promo-message" role="alert" aria-live="polite"></p>
  </section>

  <section id="delivery-section" aria-label="Delivery Details">
    <h2>Delivery Details</h2>
    <form id="delivery-form">
      <label for="address">Delivery Address:</label>
      <textarea id="address" required rows="3" placeholder="Enter delivery address"></textarea>

      <label for="delivery-date">Schedule Delivery Date & Time:</label>
      <input type="datetime-local" id="delivery-date" required />

      <label for="instructions">Delivery Instructions (optional):</label>
      <textarea id="instructions" rows="2" placeholder="Leave at door, call on arrival, etc."></textarea>
    </form>
  </section>

  <section id="payment-section" aria-label="Payment Options">
    <h2>Payment</h2>
    <div class="payment-methods">
      <label><input type="radio" name="payment" value="credit" checked /> Credit Card</label>
      <label><input type="radio" name="payment" value="ewallet" /> E-Wallet</label>
      <label><input type="radio" name="payment" value="cod" /> Cash on Delivery</label>
    </div>
    <div id="payment-info">
      <!-- Placeholder for payment details form if needed -->
      <p>Secure payment via trusted gateways. <span class="ssl-badge">SSL Secured</span></p>
    </div>
  </section>

  <section id="support-section" aria-label="Customer Support & FAQ">
    <h2>Need Help?</h2>
    <p>Chat with us: <a href="chat.html">Live Chat</a></p>
    <p>Call Support: <a href="tel:+18001234567">1-800-123-4567</a></p>
    <p><a href="faq.html">FAQ</a></p>
  </section>

<!-- Map Section -->
<h2>Delivery Location</h2>
<div class="map-container">
  <iframe 
    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2897.9900423782606!2d-80.45232902535238!3d43.41903476754679!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x882b8acdf3e1fb9d%3A0xaeb796164ad2e80c!2sFairway%20Plaza!5e0!3m2!1sen!2sca!4v1749920665751!5m2!1sen!2sca"
    allowfullscreen=""
    loading="lazy"
    referrerpolicy="no-referrer-when-downgrade">
  </iframe>
</div>


<footer style="background:#07173d; color:#e0e0e0; text-align:center; padding:20px;">
  <p>© <?= date('Y') ?> IKART Medical Store</p>
</footer>

</body>
</html>
