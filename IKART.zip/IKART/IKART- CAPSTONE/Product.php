<?php
session_start();
echo "<pre>";
print_r($_SESSION['cart']);
print_r($_SESSION['buylater']);

include(__DIR__ . '/db_connect.php');

// Initialize session arrays
if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];
if (!isset($_SESSION['buy_later'])) $_SESSION['buy_later'] = [];

// Handle Add to Cart
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    // add_to_cart logic here
}

    // Check if product exists
    $stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->bind_param("i", $pid);
    $stmt->execute();
    $result = $stmt->get_result();
    $product = $result->fetch_assoc();

    if ($product) {
        if ($_POST['action'] === 'add_to_cart') {
            if (isset($_SESSION['cart'][$pid])) {
                $_SESSION['cart'][$pid]++;
            } else {
                $_SESSION['cart'][$pid] = 1;
            }
        }

        if ($_POST['action'] === 'save_for_later') {
            $_SESSION['buy_later'][$pid] = $product;
        }
    }

    $stmt->close();
    header("Location: products.php");
    exit;
}

// Fetch products
$result = $conn->query("SELECT * FROM products");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>IKART - Products</title>
  <link href="https://fonts.googleapis.com/css2?family=Inria+Serif&display=swap" rel="stylesheet" />
  <style>
    body { font-family: 'Inria Serif', serif; background:#0a1a40; color:white; padding:20px; }
    .product { background:#132a5a; padding:15px; margin-bottom:20px; border-radius:8px; }
    form { margin-top:10px; display:inline-block; margin-right:10px; }
    input[type=submit], button { background:#007bff; border:none; padding:10px 15px; color:#fff; border-radius:5px; cursor:pointer; }
    input[type=submit]:hover, button:hover { background:#0056b3; }
    a { color:#66bfff; text-decoration:none; }
    a:hover { text-decoration:underline; }
  </style>
</head>
<body>

<h1>Products</h1>
<a href="cart.php">🛒 View Cart (<?= array_sum($_SESSION['cart']) ?>)</a> |
<a href="buylater.php">🕒 View Saved for Later (<?= count($_SESSION['buy_later']) ?>)</a>

<div>
<?php
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<div class='product'>";
        echo "<h3>" . htmlspecialchars($row['name']) . "</h3>";
        echo "<p>" . htmlspecialchars($row['description'] ?? '') . "</p>";
        echo "<p>Price: $" . number_format($row['price'], 2) . "</p>";

        // Add to Cart Form
        

        echo "<form method='POST'>";
        echo "<input type='hidden' name='product_id' value='" . $row['id'] . "'>";
        echo "<input type='hidden' name='action' value='add_to_cart'>";
        echo "<input type='submit' value='Add to Cart'>";
        echo "</form>";

        // Save for Later Form
        echo "<form method='POST'>";
        echo "<input type='hidden' name='product_id' value='" . $row['id'] . "'>";
        echo "<input type='hidden' name='action' value='save_for_later'>";
        echo "<input type='submit' value='💾 Save for Later'>";
        echo "</form>";

        echo "</div>";
